//index.js
//Jonathan McCormick, Jr. 
//BlockchainProgrammer.tech
//BlockchainProgrammer.crypto
//Censorship is coming

var dateOfUpdate = "13 Jan 2021"

function CryptoMaintainanceAlert() {
    alert("Welcome to BlockchainProgrammer.TECH, which you may browse at your convenience. Unfortunately, BlockchainProgrammer.CRYPTO is still being worked on. Please check back later if you want to see when it is ready ☺️");
}
CryptoMaintainanceAlert()
